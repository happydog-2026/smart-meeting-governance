# 会议智治与跨语言沟通平台

AI 比赛赛题 A4 参赛作品。输入会议录音或文本，输出结构化会议纪要（议题 / 结论 / 待办），并支持中英双语互译。

## 快速开始

### Windows（推荐双击启动）

1. **解压**：把 zip 解压到**英文路径、不含空格**的文件夹，例如 `D:\meeting-ai`。**不要直接在压缩包里双击**。
2. **装 Python**（只需一次）：安装 Python **3.11 ~ 3.13**（别装太新的 3.14+，部分依赖暂无安装包），安装时勾选 `Add python.exe to PATH`。
3. **双击 `start_web.bat`**：首次运行会自动创建虚拟环境并安装依赖（需联网，约几分钟）；之后每次双击即可启动。
4. 浏览器会自动打开 `http://localhost:8501`，也可手动访问。

### Mac / Linux

```bash
cd 项目目录
bash 启动.sh
```

（首次运行同样会自动建环境、装依赖。）

## 填入你自己的 Key（每台机器各用各的）

打开页面后进入 **「⚙️ 设置」** 页填写，填一次就会记住（存在本机 `data/` 下，不会随分享包泄露）：

| 项目 | 位置 | 留空时 |
| --- | --- | --- |
| 大模型（纠错 / 纪要 / 翻译 / 问答） | 「⚙️ 设置」→「🔑 大模型」 | 回退到本机 [Ollama](https://ollama.com/) 免费模型（默认 `qwen2.5:3b`，需先装并启动 Ollama） |
| 实时字幕（讯飞实时转写） | 「⚙️ 设置」→「🔊 实时转写 (讯飞)」 | 回退到浏览器自带的语音识别 |

> 程序不内置任何 key，所以分发给别人时各填各的，互不影响。
> 项目根的 `.env` 只给命令行脚本（`scripts/pipeline.py` 等）用，网页端不读它。

## 实时字幕说明

「实时字幕」页需要本地中继后端，由 `start_web.bat` / `run.py` **自动拉起**（端口 8000），一般无需手动操作。
如果该端口被占用，可先设环境变量 `RTASR_PORT=8010` 再启动。

## 常见问题（打不开 / 闪退怎么办）

| 现象 | 原因 | 解决 |
| --- | --- | --- |
| 双击后黑窗一闪就没了 | 在压缩包里直接双击了 | 先**完整解压**到文件夹再双击 |
| 双击 `bin\ffmpeg.exe` 刷出一堆英文后退出码 1 | 点错文件了 | 那是程序内部调用的工具，**不要双击**，请双击 `start_web.bat` |
| 提示 `Python not found` | 没装 Python / 没勾 PATH | 装 Python 3.11~3.13，勾选 `Add python.exe to PATH` |
| 依赖安装失败 | 网络不通 / Python 版本太新 | 换网络重试；或改装 Python 3.11~3.13 |
| 卡在 `Building wheel for opencc (pyproject.toml)` 很久或报编译错误 | 装的是 **32 位 / ARM 版 / 3.9 及以下** 的 Python，匹配不到 opencc 预编译包，退化成源码编译（需 Visual C++ 环境） | 卸载后改装 **64 位（x86-64）Python 3.11~3.13**，再删掉项目里的 `.venv` 文件夹重跑 |
| 提示「创建虚拟环境失败」 | 路径带中文/空格 | 移到 `D:\meeting-ai` 这类纯英文路径 |
| 网页报 `ModuleNotFoundError: No module named 'xxx'` | 之前依赖装了一半（网络中断/窗口被关） | 重新双击 `start_web.bat`，启动器会自动体检并补齐；仍不行就删掉 `.venv` 文件夹再双击 |
| 想看清报错 | 黑窗被关闭 | 打开 CMD，`cd` 到项目目录，手动运行 `run.py`（或 `python run.py`） |

> 想手动看详细报错：按 `Win+R` 输入 `cmd`，然后
> ```
> cd /d D:\meeting-ai
> python run.py
> ```

## 注意事项

- **首次使用「说话人识别」**会自动下载约 400MB 模型（paraformer-zh / fsmn-vad / cam++），请耐心等待。
- 语音转写模型（whisper `small`）首次也会自动下载。
- 本项目不依赖系统 ffmpeg（自带 `bin/ffmpeg.exe`）。
- 需要离线演示时，可提前把模型下载到本地，并通过 `.env` 的 `WHISPER_MODEL_DIR` 指向该目录。
- 没有样例音频时，可运行 `.venv\Scripts\python.exe scripts\make_sample.py` 用系统 TTS 现场生成。

## 目录说明

| 路径 | 说明 |
| --- | --- |
| `run.py` | 跨平台一键启动器（建环境、装依赖、启动） |
| `start_web.bat` / `启动.sh` | Windows / Mac·Linux 启动入口 |
| `app/web.py` | Streamlit 前端入口 |
| `app/main.py` | 实时字幕中继后端（FastAPI，自动拉起） |
| `app/services/` | ASR / 说话人分离 / 纠错 / 摘要 / 翻译 / 术语导入 |
| `scripts/` | 命令行脚本（转写、流水线、生成样例、打包） |
| `data/output/` | 处理结果（自动创建） |
| `项目介绍.md` | 作品说明 |
| `THIRD_PARTY_NOTICES.md` | 第三方开源组件许可 |
